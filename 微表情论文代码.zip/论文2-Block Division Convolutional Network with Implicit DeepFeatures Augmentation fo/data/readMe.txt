Put the 3-class or 5-class data to here.
